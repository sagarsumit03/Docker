package com.example.demo.constants;

public enum DBEnum {
    CLIENT_A, CLIENT_B;
}
