package com.example.demo.order.repository;

import org.springframework.data.jpa.repository.Query;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.order.domain.Order;

public interface OrderRepository extends JpaRepository<Order, Integer>{
    
    @Query(nativeQuery=true, value="select 'Sagar' from dual")
    public String select();
}

