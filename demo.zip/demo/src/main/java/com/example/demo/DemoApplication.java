package com.example.demo;

import com.example.demo.user.repository.UserRepository;
import com.example.demo.order.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;
import com.example.demo.constants.DBEnum;
import com.example.demo.config.DBContextHolder;

@RestController
@SpringBootApplication
public class DemoApplication {

	@Autowired
	OrderRepository orders;

	@Autowired
	UserRepository users;

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@GetMapping("/2")
	public String hello() {
		return orders.select();
	}

	@GetMapping("/1")
	public String hello1() {
		return users.select();
	}

	@GetMapping("/d/{id}")
	@ResponseBody
	public String initialData(@PathVariable("id") String id) {
		if (id.equalsIgnoreCase("1")) {
			System.out.print("inside first DB");
			DBContextHolder.setCurrentDb(DBEnum.CLIENT_A);
			return users.select();
		} else {
			System.out.print("inside second DB");
			DBContextHolder.setCurrentDb(DBEnum.CLIENT_B);
			return orders.select();
		}
	}
}
